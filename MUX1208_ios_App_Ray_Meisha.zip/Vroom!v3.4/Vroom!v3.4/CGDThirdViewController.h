//
//  CGDThirdViewController.h
//  Vroom!v3.4
//
//  Created by S. Meisha Ray on 8/21/12.
//  Copyright (c) 2012 Coder Girl Design. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CGDThirdViewController : UIViewController
{
    
}
-(IBAction)closeKeyboard:(id)sender;

@end
