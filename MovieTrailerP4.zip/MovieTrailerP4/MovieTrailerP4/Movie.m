//
//  Movie.m
//  MovieTrailerP4
//
//  Created by S. Meisha Ray on 10/18/12.
//  Copyright (c) 2012 Mad Monkey Applications. All rights reserved.
//

#import "Movie.h"
#import "DetailViewController.h"

@implementation Movie

@synthesize movieTitle;
@synthesize movieTimes;
@synthesize imageFile;

@end
